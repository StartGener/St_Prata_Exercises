#ifndef ac_h_

#define ac_h_

#include "abc.h"

class AC:public ABC{
	
	public:
		AC();
		~AC();
	
	virtual void At();
};

#endif

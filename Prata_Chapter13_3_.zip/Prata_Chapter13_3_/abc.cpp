#include "abc.h"

ABC::ABC(){
std::cout<<"ABC|Constructor \n";	
}

ABC::~ABC(){
std::cout<<"ABC|Destructor \n";
}

void ABC::At(){
	
}

#include "bc.h"

BC::BC(){
std::cout<<"BC|Constructor \n";	
}

BC::~BC(){
std::cout<<"BC|Destructor \n";	
}
	
void BC::At(){
	
}

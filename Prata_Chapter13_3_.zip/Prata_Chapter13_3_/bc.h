#ifndef bc_h_

#define bc_h_

#include "abc.h"

class BC:public ABC{
	
	public:
		BC();
		~BC();
	
	virtual void At();
};

#endif

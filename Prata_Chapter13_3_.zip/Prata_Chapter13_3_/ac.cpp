#include "ac.h"

AC::AC(){
std::cout<<"AC|Constructor \n";
}

AC::~AC(){
std::cout<<"AC|Destructor \n";	
}

void AC::At(){
	
}
